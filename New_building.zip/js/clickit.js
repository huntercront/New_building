        $('.open_modal1').on('click',function imclick1() {
        	$(".form-call input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick1() {
        	$(".form-call input:checkbox").click();
        });	


	$('.open_modal6').on('click',function imclick2() {
        	$(".form-comfort input:checkbox").click();
        });
	$('.close_modal, .overlay').on('click',function imtclick2() {
        	$(".form-comfort input:checkbox").click();
        });	


        $('.open_modal7').on('click',function imclick3() {
        	$(".form-cheap input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick3() {
        	$(".form-cheap input:checkbox").click();
        });	


        $('.open_modal4').on('click',function imclick4() {
        	$(".form-flat input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick4() {
        	$(".form-flat input:checkbox").click();
        });


        $('.open_modal5').on('click',function imclick5() {
        	$(".form-tour input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick5() {
        	$(".form-tour input:checkbox").click();
        });


        $('.open_modal8').on('click',function imclick6() {
        	$(".form-flat1 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick6() {
        	$(".form-flat1 input:checkbox").click();
        });


        $('.open_modal9').on('click',function imclick7() {
        	$(".form-flat2 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick7() {
        	$(".form-flat2 input:checkbox").click();
        });


        $('.open_modal10').on('click',function imclick8() {
        	$(".form-flat3 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick8() {
        	$(".form-flat3 input:checkbox").click();
        });


        $('.open_modal11').on('click',function imclick9() {
        	$(".form-flat4 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick9() {
        	$(".form-flat4 input:checkbox").click();
        });


        $('.open_modal12').on('click',function imclick10() {
        	$(".form-flat5 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick10() {
        	$(".form-flat5 input:checkbox").click();
        });


        $('.open_modal13').on('click',function imclick11() {
        	$(".form-flat6 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick11() {
        	$(".form-flat6 input:checkbox").click();
        });


        $('.open_modal14').on('click',function imclick12() {
        	$(".form-flat7 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick12() {
        	$(".form-flat7 input:checkbox").click();
        });


        $('.open_modal15').on('click',function imclick13() {
        	$(".form-flat8 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick13() {
        	$(".form-flat8 input:checkbox").click();
        });


        $('.open_modal16').on('click',function imclick14() {
        	$(".form-flat9 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick14() {
        	$(".form-flat9 input:checkbox").click();
        });


        $('.open_modal17').on('click',function imclick15() {
        	$(".form-flat10 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick15() {
        	$(".form-flat10 input:checkbox").click();
        });


        $('.open_modal18').on('click',function imclick16() {
        	$(".form-flat11 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick16() {
        	$(".form-flat11 input:checkbox").click();
        });


        $('.open_modal19').on('click',function imclick17() {
        	$(".form-flat12 input:checkbox").click();
        });
        $('.close_modal, .overlay').on('click',function imtclick17() {
        	$(".form-flat12 input:checkbox").click();
        });